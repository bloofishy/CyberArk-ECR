<html>
<head>
	<title>CyberArk ECR</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<!---<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>--->
</head>
<?php require 'topcontent-front.php'; ?>
<br><br><br><br><br><br><br><br><br>
<form action="report-template.php">
<input type="submit" value="Generate Reports?" class=toEnterStore0>
</form>
<form action="audit-compliance.php">
<input type="submit" value="Audit Compliance*" class=toEnterStoreC>
</form>
<form action="exportupdate.php">
<input type="submit" value="Re-Export Update!" class=toEnterStore1>
</form>
<form action="dbtestcon.php">
<input type="submit" value="Database Test Con" class=toEnterStore>
</form>
</html>
