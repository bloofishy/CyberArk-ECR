<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="audit-compliance-gdpr.php"; require 'topcontent.php'; ?>
<font size=4>Prior to and in Responding to a Breach (ref. Art 33)<br></font>
<p align=left><font size=4>GDPR Article 33 – Notification of a Personal Data Breach to the Supervisory Authority</font><br>The controller shall document any personal data breaches, comprising the facts relating to the personal data breach, its effects and the remedial action taken. That documentation shall enable the supervisory authority to verify compliance with this Article.</p>
<button class="collapsible"><b>CyberArk Solution</b></button>
<div class="content">
<p><b>Recording of Privilege Session Activities</b> – To detect the misuse of privilege credentials relating to a breach of personal data early in the attack life cycle, the CyberArk solution offers live monitoring and recording of user activities within the speciifc privilege session. In addition, accounting for who has accessed what personal data on which IT systems when.
</div>
<hr>

<table border=1 id=T0> <tr>
<th style="width:80px">Date</th>
<th style="width:80px">Time</th>
<th style="width:330px">Action</th>
<th>Safe</th>
<th>File</th>
<th style="width:80px">User</th>
</tr>
<p align="left"><font size=2.5>- Activities Log "Use Password" Option </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAARequestID IS NOT NULL AND CAAAction = 'Use Password' ORDER BY CAARequestID";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".$action."</td>";
	echo "<td>".$safe."</td>";
	echo "<td>".$file."</td>";
	echo "<td>".$name."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'GDPR-Response-Activities Log Use Password Option-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

<table border=1 id=T1> <tr>
<th style="width:80px">Date</th>
<th>Time</th>
<th>Action</th>
<th>App</th>
<th>Target IP</th>
<th>Proto</th>
<th>Session ID</th>
<th>Acc</th>
<th>Safe</th>
<th>File</th>
<th>User</th>
<th>Int</th>
</tr>
<p align="left"><font size=2.5>- Privilege Session Connection </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'PSM Connect'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAAActivityID'];
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$info = $row['CAAInfo2'];
	$infoex = explode(';',$info);
	$req = $row['CAARequestReason'];
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	$int = $row['CAAInterfaceId'];
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".$action."</td>";
	echo "<td>".explode('=',$infoex[0])[1]."</td>";
	echo "<td>".explode('=',$infoex[1])[1]."</td>";
	echo "<td>".explode('=',$infoex[2])[1]."</td>";
	echo "<td>".explode('=',$infoex[4])[1]."</td>";
	echo "<td>".explode('=',$infoex[6])[1]."</td>";
	echo "<td>".$safe."</td>";
	echo "<td>".$file."</td>";
	echo "<td>".$name."</td>";
	echo "<td>".$int."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table>
<p align="right">
<form method="post" action='audit-compliance-gdpr-response-activities.php'>
<button style="width:150px" class="toEnterStore0"><font size = 1.5>Session Activities</font></button></form></p>
<?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T1', 'GDPR-Response-Privilege Session Connection-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

</body>
</html>
<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
.collapsible {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  background-color: rgba(150, 150, 150, 0.7);;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: 2px solid black;
  text-align: left;
  outline: none;
  font-size: 15px;
  border-bottom: 0px solid black;
  transition: all 0.5s ease 0s;
}

.active, .collapsible:hover { background-color: #012B74; color: white; }
.collapsible:after { content: '\002B'; color: black; font-weight: bold; float: right; margin-left: 5px; }
.active:after { color: white; content: "\2212"; }
.content { padding: 0 18px; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; background-color: rgba(255, 255, 255, 0.7); border-left: 2px solid black; border-right: 2px solid black; border-bottom: 2px solid black; font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; text-align: left; }
</style>