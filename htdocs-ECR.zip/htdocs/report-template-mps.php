<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="report-template.php"; require 'topcontent.php'; ?>
<font size=4>CyberArk Master Policy Setting Report<br></font>
<p>It's a report template created to show the default master policy option set on CyberArk with the exceptions applied on other specific platforms (if any). </p>
<hr>

<table border=1 id=T0> <tr>
<th>Default Master Policy Item</th>
<th>Set</th>
</tr>
<p align="left"><font size=2.5>- <b>Default Master Policy</b> Setting Option(s)</font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CAMasterPolicySettings WHERE CAMPPolicyName = 'NULL' "; #default master policy
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAMPPolicyName'];
	$name = $row['CAMPMasterPolicySettingName'];
	$value = $row['CAMPMasterPolicySettingValue'];
	$adname = $row['CAMPMasterPolicyAdvancedSettingName'];
	$advalue = $row['CAMPMasterPolicyAdvancedSettingValue'];
	echo "<tr>";
	#echo "<td>".$identifier."</td>";
	if (isset($prevname)) {
		if ($name != $prevname) {
			echo "<td><b>".$name."</b></td>";
			echo "<td>".$value."</td>";
		} else {
			echo "<td> <b>-</b> ".$adname."</td>";
			echo "<td>".$advalue."</td>";
		}
		echo "</tr>";
	} else { echo "<td><b>".$name."</b></td>";; echo "<td>".$value."</td>"; }
	$prevname = $name;
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'Generic-Report-Default Master Policy Setting Option-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

<table border=1 id=T1> <tr>
<th>Exception Platform</th>
<th>Exception Master Policy Item</th>
<th>Set</th>
<th>Exception Child Policy Item</th>
<th>Set</th>
</tr>
<p align="left"><font size=2.5>- <b>Exception</b> Policy Setting Option(s)</font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CAMasterPolicySettings WHERE CAMPIsException = 'yes' ";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAMPPolicyName'];
	$name = $row['CAMPMasterPolicySettingName'];
	$value = $row['CAMPMasterPolicySettingValue'];
	$adname = $row['CAMPMasterPolicyAdvancedSettingName'];
	$advalue = $row['CAMPMasterPolicyAdvancedSettingValue'];
		echo "<tr>";
		echo "<td>".$identifier."</td>";
		echo "<td>".$name."</td>";
		echo "<td>".$value."</td>";
		if ($adname != 'NULL'){
		echo "<td>".$adname."</td>";
		}
		if ($advalue != 'NULL'){
		echo "<td>".$advalue."</td>";
		}
		echo "</td>";
		echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T1', 'Generic-Report-Exception Policy Setting Option-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>
</body>
</html>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
</style>