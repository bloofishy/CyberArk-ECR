<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="report-template.php"; require 'topcontent.php'; ?>
<font size=4>CyberArk Group Report<br></font>
<p>It's a report template created to show the different groups with the respective group members within CyberArk.</p>
<hr>

<table border=1 id=T0> <tr>
<th>Group</th>
<th>Member</th>
</tr>

<?php
# Specific to User/Group Report - Create List of User who are considered CyberArk Default System
$cyberdef = array("NotificationEngine","PVWAGWUser","PSMGw_COMPONENT","PVWAAppUser","PSMApp_COMPONENT","Backup","Operator","DR");

# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT CAGGroupID, CAGGroupName FROM dbo.CAGroups";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAGGroupID'];
	$name = $row['CAGGroupName'];
		echo "<tr>";
		#echo "<td>".$identifier."</td>";
		echo "<td>".$name."</td>";
		echo "<td>";
		$newq = "SELECT CAGMUserID, CAUUserName FROM dbo.CAGroupMembers gm, dbo.CAUsers u WHERE gm.CAGMUserID=u.CAUUserID AND CAGMGroupID = '".$identifier."'";
		$newstate = sqlsrv_query($conn, $newq);
		if ($newstate === false) { die (print_r(sqlsrv_errors(), true)); }
		while ($newrow = sqlsrv_fetch_array($newstate, SQLSRV_FETCH_ASSOC)) {
		$userid = $newrow['CAGMUserID'];
		$username = $newrow['CAUUserName'];
		echo " - ".$username." "."<br>";
		}
		echo "</td>";
		echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'Generic-Report-Group-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>
</body>
</html>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
</style>