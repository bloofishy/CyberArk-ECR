<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="report-template.php"; require 'topcontent.php'; ?>
<font size=4>CyberArk Session Recording Report<br></font>
<p>It's a report template created to show the list of privilege session recording logs or files stored within the CyberArk PSMRecordings safe with the corresponding creation date time. In addition, the size of the text/video recording files are listed.</p>
<hr>
		
<table border=1> <tr>
<th width=110px>Safe</th>
<th width=30px>FID</th>
<th>File</th>
<th width=80px>Date</th>
<th width=80px>Time</th>
</tr>
<p align="left"><font size=2.5>- <b>Session</b> Metadata File(s)</font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CAFiles WHERE CAFSafeName = 'PSMRecordings'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Metadata of Recording File
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$safe = $row['CAFSafeName'];
	$fileid = $row['CAFFileID'];
	$file = $row['CAFFileName'];
	$deletechk = $row['CAFDeletionDate'];
	$time = $row['CAFCreationDate'];
	if ( $deletechk == NULL ) {
		if (substr($file, -8) == '.session') {
			echo "<tr>";
			echo "<td>".$safe."</td>";
			echo "<td>".$fileid."</td>";
			echo "<td>".$file."</td>";
			#echo "<td>".$size."</td>";
			echo "<td>".$time->format("d-m-Y")."</td>";
			echo "<td>".$time->format("H:i:s")."</td>";
			echo "</tr>";
		}
	}
}
sqlsrv_free_stmt ($state);
?>
</table><hr>

<table border=1> <tr>
<th width=110px>Safe</th>
<th width=30px>FID</th>
<th>File</th>
<th width=80px>Size</th>
<th width=80px>Date</th>
<th width=80px>Time</th></tr>
<p align="left"><font size=2.5>- <b>Text</b> Key Log File(s)</font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CAFiles WHERE CAFSafeName = 'PSMRecordings'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Text Key Log File
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$safe = $row['CAFSafeName'];
	$fileid = $row['CAFFileID'];
	$file = $row['CAFFileName'];
	$size = $row['CAFSize'];
	$deletechk = $row['CAFDeletionDate'];
	$time = $row['CAFCreationDate'];
	if ( $deletechk == NULL ) {
		if (substr($file, -4) == '.txt') {
			echo "<tr>";
			echo "<td>".$safe."</td>";
			echo "<td>".$fileid."</td>";
			echo "<td>".$file."</td>";
			echo "<td>".$size."</td>";
			echo "<td>".$time->format("d-m-Y")."</td>";
			echo "<td>".$time->format("H:i:s")."</td>";
			echo "</tr>";
		}
	}
}
sqlsrv_free_stmt ($state);
?>
</table><p align="right"><font size=2.5>- *note: the file size listed are represented in Bytes.</font></p><hr>

<table border=1> <tr>
<th width=110px>Safe</th>
<th width=30px>FID</th>
<th>File</th>
<th width=80px>Size</th>
<th width=80px>Date</th>
<th width=80px>Time</th></tr>
</tr>
<p align="left"><font size=2.5>- <b>Video</b> Recording File(s)</font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CAFiles WHERE CAFSafeName = 'PSMRecordings'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Video Recording File
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$safe = $row['CAFSafeName'];
	$fileid = $row['CAFFileID'];
	$file = $row['CAFFileName'];
	$size = $row['CAFSize'];
	$deletechk = $row['CAFDeletionDate'];
	$time = $row['CAFCreationDate'];
	if ( $deletechk == NULL ) {
		if (substr($file, -4) == '.avi') {
			echo "<tr>";
			echo "<td>".$safe."</td>";
			echo "<td>".$fileid."</td>";
			echo "<td>".$file."</td>";
			echo "<td>".$size."</td>";
			echo "<td>".$time->format("d-m-Y")."</td>";
			echo "<td>".$time->format("H:i:s")."</td>";
			echo "</tr>";
		}
	}
}
sqlsrv_free_stmt ($state);
?>
</table><p align="right"><font size=2.5>- *note: the file size listed are represented in Bytes.</font></p><hr>
</body>
</html>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
</style>