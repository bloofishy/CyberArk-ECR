<html>
<body>
<?php
# Initiate & Create the Session
session_start();

# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"ECRLogin", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Testing Connection to the Database
if ($conn) { echo "Connection Database OK!<br />"; }
else { echo "Connection Database NOT OK. <br />"; die (print_r(sqlsrv_errors(), true)); }

# Prepare & Execute SQL Queries for the Database
$AID = $_POST["uname"];
$APW = $_POST["pword"];
$query = "SELECT AuthNo FROM AuthTable WHERE AuthID LIKE '".$AID."' AND AuthPW = '".$APW."'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }
if ($state) {
	$rows = sqlsrv_has_rows($state);
	if ($rows === true) { echo "Sucessful Login Credentials"; redirect("front.php"); } # Successful Login Credentials
	else { echo "Failed Login Attempt Bad Credentials"; echo "<script type=text/javascript> alert('Failed Login Attempt Bad Credentials') </script>"; redirect("index.php"); } # Failed Login Attempt Bad Credentials
}

# Create & Define Redirect Function
function redirect($url) {
    ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();
}
?>
</body>
</html>