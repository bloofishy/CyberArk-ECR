<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="report-template.php"; require 'topcontent.php'; ?>
<font size=4>CyberArk Session Recording Review Report<br></font>
<p>It's a report template created to show the list of privilege session(s) within CyberArk with the corresponding target IP address, account and other relevant information in relation to the specific unique session ID. Furthermore, the report states who has reviewed the sessions. If not stated, the session has not been reviewed before.</p>
<hr>

<table border=1 id="review"> <tr>
<th>Date</th>
<th>Time</th>
<th>Session Connection ID</th>
<th>App</th>
<th>Platform</th>
<th>Target IP</th>
<th>Account</th>
<th>CyberArk User</th>
<th>Review</th>
<th>Review Date</th>
<th>Review Time</th>

</tr>

<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "
SELECT f.CAFCreationDate, f.CAFSafeID, f.CAFFileID, f.CAFFileName, substring(f.CAFFileName, 0, charindex('.',f.CAFFileName, 0)) AS SessionID
FROM CAFiles f
WHERE f.CAFSafeName = 'PSMRecordings' AND f.CAFFileName LIKE '%.session';";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

$no = 1;
# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$time = $row['CAFCreationDate'];
	#$safe = $row['CAFSafeName']'
	#$safeid = $row['CAFSafeID'];
	#$fileid = $row['CAFFileID'];
	#$safeop = $row['CAOPSafeId'];
	#$fileop = $row['CAOPFileId'];
	$file = $row['CAFFileName'];
	#$prop = $row['CAOPObjectPropertyName'];
	#$propset = $row['CAOPObjectPropertyValue'];
	$sessionid = $row['SessionID'];
	#if ($prop === "Address" || $prop === "ConnectionComponentID" || $prop === "PolicyID" || $prop === "PSMVaultUserName" || $prop === "UserName" ) {
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	#echo "<td>".$safe."</td>";
	#echo "<td>".$safeid."</td>";
	#echo "<td>".$fileid."</td>";
	#echo "<td>".$safeop."</td>";
	#echo "<td>".$fileop."</td>";
	echo "<td>".$sessionid."</td>";
	#echo "<td>".$file."</td>";
	#echo "<td>".$prop."</td>";
	#echo "<td>".$propset."</td>";
	
	#Time (Start)
	$query1 = "SELECT p.CAOPObjectPropertyValue FROM CAFiles f, CAObjectProperties p WHERE f.CAFSafeName = 'PSMRecordings' AND p.CAOPSafeId = f.CAFSafeID AND p.CAOPFileId = f.CAFFileID AND substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) = '".$sessionid."' AND p.CAOPObjectPropertyName = 'PSMStartTime' ;";
	$state1 = sqlsrv_query($conn, $query1);
	while ($row1 = sqlsrv_fetch_array($state1, SQLSRV_FETCH_ASSOC)) { $starttime = $row1['CAOPObjectPropertyValue']; }		
	
	#Time (End)
	$query1 = "SELECT p.CAOPObjectPropertyValue FROM CAFiles f, CAObjectProperties p WHERE f.CAFSafeName = 'PSMRecordings' AND p.CAOPSafeId = f.CAFSafeID AND p.CAOPFileId = f.CAFFileID AND substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) = '".$sessionid."' AND p.CAOPObjectPropertyName = 'PSMEndTime' ;";
	$state1 = sqlsrv_query($conn, $query1);
	while ($row1 = sqlsrv_fetch_array($state1, SQLSRV_FETCH_ASSOC)) { $endtime = $row1['CAOPObjectPropertyValue']; }	
	
	$recordtime = $endtime - $starttime;
	#echo "<td>";
	#echo $recordtime;
	#echo " (s) ";
	#echo "</td>";
	
	#ConnectionComponentID (App)
	$query1 = "SELECT p.CAOPObjectPropertyValue FROM CAFiles f, CAObjectProperties p WHERE f.CAFSafeName = 'PSMRecordings' AND p.CAOPSafeId = f.CAFSafeID AND p.CAOPFileId = f.CAFFileID AND substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) = '".$sessionid."' AND p.CAOPObjectPropertyName = 'ConnectionComponentID' ;";
	$state1 = sqlsrv_query($conn, $query1);
	while ($row1 = sqlsrv_fetch_array($state1, SQLSRV_FETCH_ASSOC)) { $prop1 = $row1['CAOPObjectPropertyValue']; echo "<td>".$prop1."</td>"; }	
	
	#PolicyID (Platform)
	$query1 = "SELECT p.CAOPObjectPropertyValue FROM CAFiles f, CAObjectProperties p WHERE f.CAFSafeName = 'PSMRecordings' AND p.CAOPSafeId = f.CAFSafeID AND p.CAOPFileId = f.CAFFileID AND substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) = '".$sessionid."' AND p.CAOPObjectPropertyName = 'PolicyID' ;";
	$state1 = sqlsrv_query($conn, $query1);
	while ($row1 = sqlsrv_fetch_array($state1, SQLSRV_FETCH_ASSOC)) { $prop1 = $row1['CAOPObjectPropertyValue']; echo "<td>".$prop1."</td>"; }	
		
	#Target IP Address
	$query1 = "SELECT p.CAOPObjectPropertyValue FROM CAFiles f, CAObjectProperties p WHERE f.CAFSafeName = 'PSMRecordings' AND p.CAOPSafeId = f.CAFSafeID AND p.CAOPFileId = f.CAFFileID AND substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) = '".$sessionid."' AND p.CAOPObjectPropertyName = 'Address' ;";
	$state1 = sqlsrv_query($conn, $query1);
	while ($row1 = sqlsrv_fetch_array($state1, SQLSRV_FETCH_ASSOC)) { $prop1 = $row1['CAOPObjectPropertyValue']; echo "<td>".$prop1."</td>"; }
		
	#UserName (Account)
	$query1 = "SELECT p.CAOPObjectPropertyValue FROM CAFiles f, CAObjectProperties p WHERE f.CAFSafeName = 'PSMRecordings' AND p.CAOPSafeId = f.CAFSafeID AND p.CAOPFileId = f.CAFFileID AND substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) = '".$sessionid."' AND p.CAOPObjectPropertyName = 'UserName' ;";
	$state1 = sqlsrv_query($conn, $query1);
	while ($row1 = sqlsrv_fetch_array($state1, SQLSRV_FETCH_ASSOC)) { $prop1 = $row1['CAOPObjectPropertyValue']; echo "<td>".$prop1."</td>"; }	
		
	#PSMVaultUserName (CyberArk User)
	$query1 = "SELECT p.CAOPObjectPropertyValue FROM CAFiles f, CAObjectProperties p WHERE f.CAFSafeName = 'PSMRecordings' AND p.CAOPSafeId = f.CAFSafeID AND p.CAOPFileId = f.CAFFileID AND substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) = '".$sessionid."' AND p.CAOPObjectPropertyName = 'PSMVaultUserName' ;";
	$state1 = sqlsrv_query($conn, $query1);
	while ($row1 = sqlsrv_fetch_array($state1, SQLSRV_FETCH_ASSOC)) { $prop1 = $row1['CAOPObjectPropertyValue']; echo "<td>".$prop1."</td>"; }	
	
	$queryx = "SELECT TOP 1 CAATime, CAAUserName, substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) AS SessionID FROM CALog logs, CAFiles f WHERE logs.CAAInfo1ID = f.CAFFileID AND logs.CAASafeID = f.CAFSafeID AND CAFSafeName= 'PSMRecordings' AND logs.CAAAction = 'Open File' AND substring(CAFFileName, 0, charindex('.', CAFFileName, 0)) = '".$sessionid."' ORDER BY CAATime DESC;";
	$statex = sqlsrv_query($conn, $queryx);
	while ($rowx = sqlsrv_fetch_array($statex, SQLSRV_FETCH_ASSOC)) {
		$rev = $rowx['CAAUserName'];
		$revtime = $rowx['CAATime'];
		echo "<td>".$rev."</td>";
		echo "<td>".$revtime->format("d-m-Y")."</td>";
		echo "<td>".$revtime->format("H:i:s")."</td>";
		echo "</tr>";
	} 
	echo "</tr>";
}

sqlsrv_free_stmt ($state);
?>
</table><hr>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick='document.getElementById("review").classList.toggle("show-review")'><font size = 1.5>Show/Hide Review(s)</font></button></p>
<?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('review', 'Generic-Report-Review-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>
</body>
</html>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
#review td { #transition: all 0.5s ease 0s; }
#review tr > *:nth-child(9) { display: none; }
#review tr > *:nth-child(10) { display: none; }
#review tr > *:nth-child(11) { display: none; }
#review.show-review tr > *:nth-child(9) { display: table-cell; }
#review.show-review tr > *:nth-child(10) { display: table-cell; }
#review.show-review tr > *:nth-child(11) { display: table-cell; }
</style>