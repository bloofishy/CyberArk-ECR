<html>
<ul>
<li><a href=<?php echo $prev; ?>>prev</a></li>
<li><a href="front.php"><img src="home.png" align="top" height=15px> CyberArk Extensive Customized Reporting</a></li>
<li><a href="report-template.php">Report</a></li>
<li><a href="audit-compliance.php">Audit</a></li>
<li style="float:right"><a class="activelogin" href="index.php">root</a></li>
</ul><br><br><br>
</html>


