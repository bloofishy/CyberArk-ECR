<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="audit-compliance-mas.php"; require 'topcontent.php'; ?>
<font size=4>5.1 Due Diligence<br></font>
<p>5.1.4 IT outsourcing should not result in any weakening or degradation of the FI’s internal controls. The FI should require the service provider to employ a high standard of care and diligence in its security policies, procedures and controls to protect the confidentiality and security of its sensitive or confidential information, such as customer data, computer files, records, object programs and source codes.</p>
<button class="collapsible"><b>CyberArk Solution</b></button>
<div class="content">
<p><b>PSM</b> – For external outsource vendors to access system(s) within the network whilst keeping a high level of security & scrutiny. It is possible to temporarily create a user or group within CyberArk for the IT outsource with a set of defined access rights only to certain specific devices required to complete their job. (w/o compromising or weakening the existing security controls)</p>
</div>
<hr>

<?php session_start(); ?>
<html><body><form action='' method='post'>
<p>
<label for="new">Add to List:</label>
<input type='text' name='newitem' id='newitem'/>
<input type='submit' name='add' value='Add' />
<input type='submit' name='reset' value='Reset' />
</p>
<?php
if (isset($_POST['add'])) {
if(!array_key_exists("list", $_SESSION)) { $_SESSION["list"] = array(); }
array_push($_SESSION["list"], $_POST["newitem"]);
}
if(isset($_POST['reset'])) { $_SESSION["list"] = array(); }
if(array_key_exists("list", $_SESSION)) {
echo "Existing List of IT Outsource ( ";
echo implode(" + ", $_SESSION["list"]);
echo " ) ";
}
?>
</form></body></html>

<table border=1 id=T0> <tr>
<th style="width:80px">Date</th>
<th>Time</th>
<th>Action</th>
<th>App</th>
<th>Target IP</th>
<th>Proto</th>
<th>Session ID</th>
<th>Acc</th>
<th>Safe</th>
<th>File</th>
<th>User</th>
<th>Int</th>
</tr>
<p align="left"><font size=2.5>- <b>PSM</b> IT Outsource Session Connection </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'PSM Connect'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAAActivityID'];
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$info = $row['CAAInfo2'];
	$infoex = explode(';',$info);
	$req = $row['CAARequestReason'];
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	$int = $row['CAAInterfaceId'];
	if (in_array($name,$_SESSION['list'])) { 
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".$action."</td>";
	echo "<td>".explode('=',$infoex[0])[1]."</td>";
	echo "<td>".explode('=',$infoex[1])[1]."</td>";
	echo "<td>".explode('=',$infoex[2])[1]."</td>";
	echo "<td>".explode('=',$infoex[4])[1]."</td>";
	echo "<td>".explode('=',$infoex[6])[1]."</td>";
	echo "<td>".$safe."</td>";
	echo "<td>".$file."</td>";
	echo "<td>".$name."</td>";
	echo "<td>".$int."</td>";
	echo "</tr>";
	}
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'MAS-TRM-5.1-PSM IT Outsource Session Connection-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

</body>
</html>
<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
.collapsible {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  background-color: rgba(150, 150, 150, 0.7);;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: 2px solid black;
  text-align: left;
  outline: none;
  font-size: 15px;
  border-bottom: 0px solid black;
  transition: all 0.5s ease 0s;
}

.active, .collapsible:hover { background-color: #012B74; color: white; }
.collapsible:after { content: '\002B'; color: black; font-weight: bold; float: right; margin-left: 5px; }
.active:after { color: white; content: "\2212"; }
.content { padding: 0 18px; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; background-color: rgba(255, 255, 255, 0.7); border-left: 2px solid black; border-right: 2px solid black; border-bottom: 2px solid black; font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; text-align: left; }
</style>