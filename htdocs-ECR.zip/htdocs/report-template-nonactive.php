<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="report-template.php"; require 'topcontent.php'; ?>
<font size=4>Inactive CyberArk User Report<br></font>
<p>It's a report template created to show the list of inactive users within CyberArk who have not login for a certain no of days. In addition, the report presents the user's last login date with the corresponding no of days since then.</p>

<?php
# Reference Now Date Time
echo "Time of Reference: ".date("d-m-Y")."<br>";
?>

<font size=1.9>
<div class="container">
<form action="" method="post">
<label for="non"> no of non-active day <?php if (isset($_POST["non"])){ $non = $_POST["non"]; } else { $non = '0'; } echo "(<b>".$non."</b>)"; ?> : </label>
<input type="number" step="1" min="0" name="non" placeholder="Enter" style="font-size: 11; height:19px; width:50px; vertical-align: middle;">
<button type="submit" value="Filter" style="font-size: 11; height:19px; width:50px; vertical-align: middle;">Filter</button><br>
<input type="submit" name="non" value=7 style="font-size: 11; height:19px; width:50px; vertical-align: middle; background: none; border: none; font-color: #012B74;">
<input type="submit" name="non" value=14 style="font-size: 11; height:19px; width:50px; vertical-align: middle; background: none; border: none;">
<input type="submit" name="non" value=30 style="font-size: 11; height:19px; width:50px; vertical-align: middle; background: none; border: none;">
<input type="submit" name="non" value=60 style="font-size: 11; height:19px; width:50px; vertical-align: middle; background: none; border: none;">
<input type="submit" name="non" value=90 style="font-size: 11; height:19px; width:50px; vertical-align: middle; background: none; border: none;">
<br>
</form>
</div>
</font>
<hr>

<table border=1 id=T0> <tr>
<th width=30px>No.</th>
<th>ID</th>
<th>Name</th>
<th>LastLogonDate</th>
<th>Days (since prev login)</th>
</tr>

<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT CAUUserID, CAUUserName, CAULastLogonDate FROM dbo.CAUsers";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }


if (isset($_POST["non"])){ $non = $_POST["non"]; } else { $non = 0; } # If not set, set to 0
# Print Result of Non-Active for Certain No of Day
$no = 1;
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAUUserID'];
	$name = $row['CAUUserName'];
	$logondate = $row['CAULastLogonDate'];
	$nowdate = date_create(date("d-m-Y"));
	if (!empty($logondate)) {
		$intv = date_diff($logondate, $nowdate);
		$intv_no = (int)$intv->format('%a');
		if ($intv_no >= $non) {
		echo "<tr>";
		echo "<td>".$no."</td>"; $no++;
		echo "<td>".$row['CAUUserID']."</td>";
		echo "<td>".$row['CAUUserName']."</td>";
		echo "<td>".$logondate->format("d-m-Y")."</td>";
		echo "<td>".$intv_no."</td>";
		echo "</tr>";
		} 
	} 
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'Generic-Report-Nonactive-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>
</body>
</html>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
hr { border: 0; height: 3px; background: #333; background-image: linear-gradient(to right,#ccc,#012B74,#ccc); }
</style>



<?php
/* Display ALL User
// Output the Results from the Database
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAUUserID'];
	$name = $row['CAUUserName'];
	$logondate = $row['CAULastLogonDate'];
	$nowdate = date_create(date("d-m-Y"));
		echo "<tr>";
		echo "<td>".$row['CAUUserID']."</td>";
		echo "<td>".$row['CAUUserName']."</td>";
	if (!empty($logondate)) {
		$intv = date_diff($logondate, $nowdate);
		$intv_no = $intv->format('%a');
		echo "<td>".$logondate->format("d-m-Y")."</td>";
		echo "<td>".$intv_no."</td>";
		echo "</tr>";
	} else { echo "<td>No Prev Login Found</td>"; echo "<td>Not Applicable</td>"; echo "</tr>"; } 
}
*/
?>