<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="report-template.php"; require 'topcontent.php'; ?>
<font size=4>CyberArk Ext User Report<br></font>
<p>It's a report template created to show the list of ext users who authenticate into CyberArk from the LDAP integration with the AD. </p>
<hr>

<table border=1 id="info"> <tr>
<th>ID</th>
<th>User</th>
<th>CyberArk Group Map</th>
<th>FQDN</th>
<th>DC</th>
<th>First Name</th>
<th>Last Name</th>
<th>E-Mail</th>
</tr>

<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CAUsers WHERE CAUExternalInternal != '1'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAUUserID'];
	$name = $row['CAUUserName'];
	$map = $row['CAUMapName'];
	$FQDN = $row['CAULDAPFullDN'];
	$dc = $row['CAULDAPDirectory'];
	$firstname = $row['CAUFirstName'];
	$othername = $row['CAULastName'];
	$businessemail = $row['CAUBusinessEmail'];
	echo "<tr>";
	echo "<td>".$identifier."</td>";
	echo "<td>".$name."</td>";
	echo "<td>".$map."</td>";
	echo "<td>".$FQDN."</td>";
	echo "<td>".$dc."</td>";
	echo "<td>".$firstname."</td>";
	echo "<td>".$othername."</td>";
	echo "<td>".$businessemail."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick='document.getElementById("info").classList.toggle("show-info")'><font size = 1.5>Show/Hide Info</font></button></p>
<?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('info', 'Generic-Report-Ext-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>
</body>
</html>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
#info td { #transition: all 0.5s ease 0s; }
#info tr > *:nth-child(6) { display: none; }
#info tr > *:nth-child(7) { display: none; }
#info tr > *:nth-child(8) { display: none; }
#info.show-info tr > *:nth-child(6) { display: table-cell; }
#info.show-info tr > *:nth-child(7) { display: table-cell; }
#info.show-info tr > *:nth-child(8) { display: table-cell; }
</style>