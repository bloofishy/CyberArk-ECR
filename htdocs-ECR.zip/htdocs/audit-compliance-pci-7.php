<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="audit-compliance-pci.php"; require 'topcontent.php'; ?>
<font size=4>– Implement Strong Access Control Measures –<br></font>
<p>(7) Restrict access to cardholder data by business need-to-know</p>
<button class="collapsible"><b>CyberArk Solution</b></button>
<div class="content">
<p><b>EPV + PSM - Privilege Session Connection + Password Retrieval Workflow Process.</b> In the CyberArk solution, the access to IT systems in the network environment come from the session connection(s) the PSM component creates. Furthermore, it offers the feature to define a multi-tier password retrieval workflow process with a requestor & approver. Hence, it strenghtens security to privilege access with the need to authorize from the resource owner.</p>
</div>
<hr>

<table border=1 id=T0> <tr>
<th style="width:80px">Date</th>
<th>Time</th>
<th>Session ID</th>
<th>App</th>
<th>Target IP</th>
<th>Acc</th>
<th>User</th>
</tr>
<p align="left"><font size=2.5>- <b>PSM</b> Session Connection </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'PSM Connect'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAAActivityID'];
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$info = $row['CAAInfo2'];
	$infoex = explode(';',$info);
	$req = $row['CAARequestReason'];
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".explode('=',$infoex[4])[1]."</td>";
	echo "<td>".explode('=',$infoex[0])[1]."</td>";
	echo "<td>".explode('=',$infoex[1])[1]."</td>";
	echo "<td>".explode('=',$infoex[6])[1]."</td>";
	echo "<td>".$name."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'PCI-7-PSM Session Connection-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

<table border=1 id="retrievepwdworkflow"> <tr>
<th style="width:80px">Date</th>
<th style="width:80px">Time</th>
<th style="width:30px">ID</th>
<th style="width:330px">Action</th>
<th>Safe</th>
<th>File</th>
<th style="width:80px">User</th>
<th style="width:80px">Requestor</th>
<th style="width:35%">Reason</th>
</tr>
<p align="left"><font size=2.5>- <b>Retrieve</b> Password Object Workflow Process with Requestor & Approver </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAARequestID IS NOT NULL AND ( CAAAction = 'Get File Request' OR CAAAction = 'Confirm Get File' OR CAAAction = 'Last Required Confirmation To Get File Given' OR CAAAction = 'Use Password' ) ORDER BY CAARequestID"; #retrieve file request to pwd object
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$time = $row['CAATime'];
	$reqid = $row['CAARequestID'];
	$action = $row['CAAAction'];
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	$reqperson = $row['CAAInfo2'];
	$reqreason = $row['CAARequestReason'];
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".$reqid."</td>";
	if ($action === "Get File Request") { echo "<td>Get File <b>Request</b></td>"; } else if ($action === "Confirm Get File") { echo "<td><b>Confirm</b> Get File</td>"; } else { echo "<td>".$action."</td>"; }
	echo "<td>".$safe."</td>";
	echo "<td>".$file."</td>";
	echo "<td>".$name."</td>";
	if ($reqperson != NULL) { echo "<td>".$reqperson."</td>"; } else { echo "<td>"."-"."</td>"; }
	echo "<td>".$reqreason."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick='document.getElementById("retrievepwdworkflow").classList.toggle("hide-reason")'><font size = 1.5>Show/Hide Reason(s)</font></button></p>
<?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('retrievepwdworkflow', 'PCI-7-Retrieve Password Object Workflow Process-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

<table border=1 id=T1> <tr>
<th style="width:80px">Date</th>
<th>Time</th>
<th>Action</th>
<th>Req</th>
<th>Safe</th>
<th>Target Info File</th>
<th>User</th>
</tr>
<p align="left"><font size=2.5>- <b>PVWA</b> Password Retrieval (Show) </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'Retrieve Password' AND CAAInterfaceId = 'PVWA' "; #retrieve pwd from pvwa
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAAActivityID'];
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$req = $row['CAARequestReason'];
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".substr($req, 8, 14)."</td>"; # OR $action for Retrieve Password
	echo "<td>".substr($req, +23)."</td>";
	echo "<td>".$safe."</td>";
	echo "<td>".$file."</td>";
	echo "<td>".$name."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T1', 'PCI-7-PVWA Password Retrieval-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

</body>
</html>
<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
.collapsible {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  background-color: rgba(150, 150, 150, 0.7);;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: 2px solid black;
  text-align: left;
  outline: none;
  font-size: 15px;
  border-bottom: 0px solid black;
  transition: all 0.5s ease 0s;
}

.active, .collapsible:hover { background-color: #012B74; color: white; }
.collapsible:after { content: '\002B'; color: black; font-weight: bold; float: right; margin-left: 5px; }
.active:after { color: white; content: "\2212"; }
.content { padding: 0 18px; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; background-color: rgba(255, 255, 255, 0.7); border-left: 2px solid black; border-right: 2px solid black; border-bottom: 2px solid black; font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; text-align: left; }
#retrievepwdworkflow td { #transition: all 0.5s ease 0s; }
#retrievepwdworkflow tr > *:nth-child(9) { display: none; }
#retrievepwdworkflow.hide-reason tr > *:nth-child(9) { display: table-cell; }
</style>