<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<ul>
<li><a href="audit-compliance.php">prev</a></li>
<li><a href="front.php"><img src="home.png" align="top" height=15px> CyberArk Extensive Customized Reporting</a></li>
<li><a href="report-template.php">Report</a></li>
<li><a href="audit-compliance.php">Audit</a></li>
<li style="float:right"><a class="active" href="index.php">root</a></li>
</ul><br><br><br>
<font size=4>General Data Protection Regulation<br></font>
<br>
<p>The GDPR has 3 areas that are relevant to CyberArk's Privilege Account Security solution. Here's a selection of reports with reference to specific compliance policies from the GDPR.</p>

<div class="menu">
<p><font size=3>– Protecting Access to Personal Data (ref. Art 25, 32) –</font></p>
<a class="cyberblue" href="audit-compliance-gdpr-protect.php"><p><br>GDPR Article 25 & 32 - Data Protection by Design and by Default + Security of Processing</p></a>
</div>

<div class="menu">
<p><font size=3>– Prior to and in Responding to a Breach (ref. Art 33) –</font></p>
<a class="cyberblue" href="audit-compliance-gdpr-response.php"><p><br>GDPR Article 33 - Notification of a Personal Data Breach to the Supervisory Authority</p></a>
</div>

<div class="menu">
<p><font size=3>– Demonstrate GDPR Compliance (ref. Art 82) –</font></p>
<a class="cyberblue" href="audit-compliance-gdpr-comp.php"><p><br>GDPR Article 82 - Right to Compensation and Liability</p></a>
</div>

<style>
a { color: #FFF; text-decoration: none; transition: all 0.5s ease 0s; }
.menu { width: 750px; margin: 30px auto; }
.menu a { width: 725px; height: 90px; display: block; margin: 4px; text-align: left; float:left; opacity: 0.8; margin-bottom: 30px; margin-top: 10px; padding-left: 15px; }
.cyberblue { background: #012B74; }
a:hover { opacity: 1; }
</style>