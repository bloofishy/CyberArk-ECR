<html>
<body>
<?php
# Specifying the Database with SQL Authentication Cred to CyberArk Database
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Testing Connection to the Database
if ($conn) { echo "<script>alert('Hi');</script>"; redirect("front.php"); }
else { echo "Connection Database NOT OK. <br />"; die (print_r(sqlsrv_errors(), true)); }

# Create & Define Redirect Function
function redirect($url) {
    ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();
}
?>
</body>
</html>