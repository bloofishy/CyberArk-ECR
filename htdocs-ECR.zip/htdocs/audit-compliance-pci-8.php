<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="audit-compliance-pci.php"; require 'topcontent.php'; ?>
<font size=4>– Implement Strong Access Control Measures –<br></font>
<p>(8) Assign a unique ID to each person with a computer access</p>
<button class="collapsible"><b>CyberArk Solution</b></button>
<div class="content">
<p><b>EPV</b> - In the CyberArk solution, the people who have access to IT computers within CyberArk are assigned to a unique ID identifier. From the perspective of cyber security, it is critical to create unique identities for the different people with IT access to ensure integrity in the logs of who perform what activities. Hence, CyberArk has the default feature of creating a unique ID for each CyberArk User/Admin added or stored into the EPV.</p>
</div>
<hr>

<table border=1 id=T0> <tr>
<th>ID</th>
<th>User</th>
<th>CyberArk Group Map</th>
<th>FQDN</th>
<th>DC</th>
<th>First Name</th>
<th>Last Name</th>
<th>E-Mail</th>
</tr>

<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CAUsers";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAUUserID'];
	$name = $row['CAUUserName'];
	$map = $row['CAUMapName'];
	$FQDN = $row['CAULDAPFullDN'];
	$dc = $row['CAULDAPDirectory'];
	$firstname = $row['CAUFirstName'];
	$othername = $row['CAULastName'];
	$businessemail = $row['CAUBusinessEmail'];
	echo "<tr>";
	echo "<td>".$identifier."</td>";
	echo "<td>".$name."</td>";
	echo "<td>".$map."</td>";
	echo "<td>".$FQDN."</td>";
	echo "<td>".$dc."</td>";
	echo "<td>".$firstname."</td>";
	echo "<td>".$othername."</td>";
	echo "<td>".$businessemail."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'PCI-8-EPV Unique ID-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

</body>
</html>
<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
.collapsible {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  background-color: rgba(150, 150, 150, 0.7);;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: 2px solid black;
  text-align: left;
  outline: none;
  font-size: 15px;
  border-bottom: 0px solid black;
  transition: all 0.5s ease 0s;
}

.active, .collapsible:hover { background-color: #012B74; color: white; }
.collapsible:after { content: '\002B'; color: black; font-weight: bold; float: right; margin-left: 5px; }
.active:after { color: white; content: "\2212"; }
.content { padding: 0 18px; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; background-color: rgba(255, 255, 255, 0.7); border-left: 2px solid black; border-right: 2px solid black; border-bottom: 2px solid black; font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; text-align: left; }
</style>
