<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<ul>
<li><a href="audit-compliance.php">prev</a></li>
<li><a href="front.php"><img src="home.png" align="top" height=15px> CyberArk Extensive Customized Reporting</a></li>
<li><a href="report-template.php">Report</a></li>
<li><a href="audit-compliance.php">Audit</a></li>
<li style="float:right"><a class="active" href="index.php">root</a></li>
</ul><br><br><br>
<font size=4>Monetary Authority of Singapore - Technology Risk Management Guideline<br></font>
<br>
<p>The MAS-TRM has a few areas that are relevant to CyberArk's Privilege Account Security solution. Here's a selection of reports with reference to specific compliance policies from the MAS-TRM.</p>
<div class="menu">
<a class="cyberblue" href="audit-compliance-mas-3.2.php"><p><br>Section 3.2<br>IT Policies, Standards & Procedures</p></a>
<a class="cyberblue" href="audit-compliance-mas-4.1.php"><p><br>Section 4.1<br>Information System Assets</p></a>
<a class="cyberblue" href="audit-compliance-mas-5.1.php"><p><br>Section 5.1<br>Due Diligence</p></a>
<a class="cyberblue" href="audit-compliance-mas-7.1.php"><p><br>Section 7.1<br>Change Management</p></a>
<a class="cyberblue" href="audit-compliance-mas-9.1.php"><p><br>Section 9.1<br>Data Loss Prevention</p></a>
<a class="cyberblue" href="audit-compliance-mas-11.1.1.php"><p><br>Section 11.1<br>User Access Mgmt</p></a>
<a class="cyberblue" href="audit-compliance-mas-11.2.3e.php"><p><br>Section 11.2<br>Privilege Access Mgmt</p></a>
</div>
</html>

<style>
a { color: #FFF; text-decoration: none; transition: all 0.5s ease 0s; }
.menu { width: 930px; margin: 30px auto; }
.menu a { width: 300px; height: 105px; display: block; margin: 4px; text-align: center; float:left; opacity: 0.8; }
.cyberblue { background: #012B74; }
a:hover { opacity: 1; }
</style>