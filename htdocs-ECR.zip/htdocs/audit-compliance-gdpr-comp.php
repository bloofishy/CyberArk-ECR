<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="audit-compliance-gdpr.php"; require 'topcontent.php'; ?>
<font size=4>Demonstrate GDPR Compliance (ref. Art 82)<br></font>
<p align=left><font size=4>GDPR Article 82 – Right to Compensation and Liability</font><br>Any controller involved in processing shall be liable for the damage caused by processing which infringes this Regulation. A processor shall be liable for the damage caused by processing only where it has not complied with obligations of this Regulation specifically directed to processors or where it has acted outside or contrary to lawful instructions of the controller. A controller or processor shall be exempt from liability if it proves that it is not in any way responsible for the event giving rise to the damage.</p>
<button class="collapsible"><b>CyberArk Solution</b></button>
<div class="content">
<p><b>Privilege Session Log</b> - In the CyberArk solution, the recording of privilege session activities provide tamper-proof audit logs & session recordings of who and what (applications) access IT system(s) to demonstrate audit integrity. In addition, the CyberArk solution enforces access controls to ensure that only the right users are able to access - or request access to - authorized credentials. Hence, offering a secure audit log of privilege access to IT systems(s) or application containing personal data to defend against possible claims in non-compliance to the GDPR.
</div>
<hr>

<table border=1 id=T0> <tr>
<th style="width:80px">Date</th>
<th style="width:80px">Time</th>
<th style="width:330px">Action</th>
<th>Safe</th>
<th>File</th>
<th style="width:80px">User</th>
</tr>
<p align="left"><font size=2.5>- Activities Log "Use Password" Option </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAARequestID IS NOT NULL AND CAAAction = 'Use Password' ORDER BY CAARequestID";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".$action."</td>";
	echo "<td>".$safe."</td>";
	echo "<td>".$file."</td>";
	echo "<td>".$name."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'GDPR-Compliance-Activities Log Use Password Option-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

<table border=1 id=T1> <tr>
<th style="width:80px">Date</th>
<th>Time</th>
<th>Action</th>
<th>App</th>
<th>Target IP</th>
<th>Proto</th>
<th>Session ID</th>
<th>Acc</th>
<th>Safe</th>
<th>File</th>
<th>User</th>
<th>Int</th>
</tr>
<p align="left"><font size=2.5>- Privilege Session Connection </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'PSM Connect'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAAActivityID'];
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$info = $row['CAAInfo2'];
	$infoex = explode(';',$info);
	$req = $row['CAARequestReason'];
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	$int = $row['CAAInterfaceId'];
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".$action."</td>";
	echo "<td>".explode('=',$infoex[0])[1]."</td>";
	echo "<td>".explode('=',$infoex[1])[1]."</td>";
	echo "<td>".explode('=',$infoex[2])[1]."</td>";
	echo "<td>".explode('=',$infoex[4])[1]."</td>";
	echo "<td>".explode('=',$infoex[6])[1]."</td>";
	echo "<td>".$safe."</td>";
	echo "<td>".$file."</td>";
	echo "<td>".$name."</td>";
	echo "<td>".$int."</td>";
	echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T1', 'GDPR-Compliance-Privilege Session Connection-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>

</body>
</html>
<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
.collapsible {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  background-color: rgba(150, 150, 150, 0.7);;
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: 2px solid black;
  text-align: left;
  outline: none;
  font-size: 15px;
  border-bottom: 0px solid black;
  transition: all 0.5s ease 0s;
}

.active, .collapsible:hover { background-color: #012B74; color: white; }
.collapsible:after { content: '\002B'; color: black; font-weight: bold; float: right; margin-left: 5px; }
.active:after { color: white; content: "\2212"; }
.content { padding: 0 18px; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; background-color: rgba(255, 255, 255, 0.7); border-left: 2px solid black; border-right: 2px solid black; border-bottom: 2px solid black; font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; text-align: left; }
</style>