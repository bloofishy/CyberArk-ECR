<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="report-template.php"; require 'topcontent.php'; ?>
<font size=4>Successful CyberArk Login Report<br></font>
<p>It's a report template created to show the successful login attempts to CyberArk from the different interfaces with the corrensponding IP address it has been accessed from with filtering options referencing to the person.</p>

<font size=1.9>
<div class="container">
<form action="" method="post">
<label for="intfcheck"> Login Interface <?php if (isset($_POST["intfcheck"])){ $intfcheck = $_POST["intfcheck"]; } else { $intfcheck = 'Other'; } echo "(<b>".$intfcheck."</b>)"; ?> : </label>
<input type="radio" name="intfcheck" value="PVWA" style="height:15px; width:15px; vertical-align: middle;"> PVWA 
<input type="radio" name="intfcheck" value="WINCLIENT" style="height:15px; width:15px; vertical-align: middle;"> PrivateArk 
<input type="radio" name="intfcheck" value="EVD" style="height:15px; width:15px; vertical-align: middle;"> EVD 
<input type="radio" name="intfcheck" value="INSTALL" style="height:15px; width:15px; vertical-align: middle;"> CyberArk Installation 
<input type="radio" name="intfcheck" value="Other" style="height:15px; width:15px; vertical-align: middle;" required> Other 
<button type="submit" value="Filter" style="font-size: 11; height:19px; width:50px; vertical-align: middle;">Filter</button><br>
<br><label for="person">Filter Reference to Login User:
<?php if (isset($_POST["intfcheck"]) && $_POST["person"] != NULL){ $person = $_POST["person"]; } else { $person = 'None'; } echo "(<b>".$person."</b>)"; ?>
<br><input type="text" name="person"><br></label>
</form>
</div>
</font>
<hr>

<table border=1 id=T0> <tr>
<th>No.</th>
<th>Date</th>
<th>Time</th>
<th>Action</th>
<th>UserID</th>
<th>UserName</th>
<th>LoginFromIP</th>
<th>InterfaceID</th>
</tr>

<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'Logon'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

$no = 1;
# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$time = $row['CAATime'];
	$identifier = $row['CAAAction'];
	$uid = $row['CAAUserID'];
	$name = $row['CAAUserName'];
	$info = $row['CAAInfo1'];
	$intf = $row['CAAInterfaceId'];
	if (isset($_POST["intfcheck"])){ $intfcheck = $_POST["intfcheck"]; } else { $intfcheck = 'Other'; } # If No Filter Set, Other = Everything 
	if  ($intfcheck === 'Other' && $person === 'None') { # Print Other
		echo "<tr>";
		echo "<td>".$no."</td>"; $no++;
		echo "<td>".$time->format("d-m-Y")."</td>";
		echo "<td>".$time->format("H:i:s")."</td>";
		echo "<td>".$identifier."</td>";
		echo "<td>".$uid."</td>";
		echo "<td>".$name."</td>";
		echo "<td>".$info."</td>";
		echo "<td>".$intf."</td>";
		echo "</tr>";
	} else if (strcasecmp ($intf, $intfcheck) == 0 && $person === 'None') {
		echo "<tr>";
		echo "<td>".$no."</td>"; $no++;
		echo "<td>".$time->format("d-m-Y")."</td>";
		echo "<td>".$time->format("H:i:s")."</td>";
		echo "<td>".$identifier."</td>";
		echo "<td>".$uid."</td>";
		echo "<td>".$name."</td>";
		echo "<td>".$info."</td>";
		echo "<td>".$intf."</td>";
		echo "</tr>";
	} else if ($intfcheck === 'Other' && $person === $name) {
		echo "<tr>";
		echo "<td>".$no."</td>"; $no++;
		echo "<td>".$time->format("d-m-Y")."</td>";
		echo "<td>".$time->format("H:i:s")."</td>";
		echo "<td>".$identifier."</td>";
		echo "<td>".$uid."</td>";
		echo "<td>".$name."</td>";
		echo "<td>".$info."</td>";
		echo "<td>".$intf."</td>";
		echo "</tr>";
	} else if (strcasecmp ($intf, $intfcheck) == 0 && $person === $name) {
		echo "<tr>";
		echo "<td>".$no."</td>"; $no++;
		echo "<td>".$time->format("d-m-Y")."</td>";
		echo "<td>".$time->format("H:i:s")."</td>";
		echo "<td>".$identifier."</td>";
		echo "<td>".$uid."</td>";
		echo "<td>".$name."</td>";
		echo "<td>".$info."</td>";
		echo "<td>".$intf."</td>";
		echo "</tr>";
	}
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'Generic-Report-Successful CyberArk Login-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>
</body>
</html>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
</style>