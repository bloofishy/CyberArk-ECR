<!DOCTYPE html>
<html>
<head>
	<title>CyberArk ECR</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
	<!---<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>--->
</head>
<body>
	<br><br><br><h1>
	<img src = "pic/cyberark.jpg" height = 300px align = center>
	<br>CyberArk Extensive Customized Reporting</h1>
	<p>Here's the CyberArk Extensive Customized Reporting project, it's an open source web platform with an interactive interface created for report generation</p>
	<button class=toEnterStore type="submit" onclick="document.getElementById('id01').style.display='block'">Login</button><br>
	<br><br><br>
	<!-- The Login Box -->
	<div id="id01" class="modal">
	<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
	<form class="modal-content animate" action="login.php" method="post">
	<h1>Login</h1>
    <div class="container">
	<label for="item_name">Username</label><br>
    <input type="text" placeholder="Enter Username" name="uname" required>
	<br>
	<label for="item_description">Password</label><br>
    <input type="password" placeholder="Enter Password" name="pword" required>
	<br>
    <input type="submit" value="Enter">
    </div>
	</form>
	</div>
</body>
</html>



<style>
th {background-color: #FF7D49;}
.active {background-color: #FF7D49;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
</style>

<style>
/* The Modal (Background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 50px;
	padding: 50px 0px;
}

/* The Modal (Content/Box) */
.modal-content {
    background-color: #fefefe;
    margin: 15px auto;
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
	height: 300px;
	padding-top: 40px;
}

/* The Close Button */
.close {
    /* Position it in the top right corner outside of the modal */
    position: absolute;
    right: 25px;
    top: 0; 
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

/* The Close Button (Hover) */
.close:hover, .close:focus {color: #012B74; cursor: pointer;}

/* Add Zoom Animation */
.animate {-webkit-animation: animatezoom 0.6s; animation: animatezoom 0.6s}
@-webkit-keyframes animatezoom {from {-webkit-transform: scale(0)} to {-webkit-transform: scale(1)}}
@keyframes animatezoom {from {transform: scale(0)} to {transform: scale(1)}}

/* Basic Design */
h1 {text-align:center; font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; color: black;}
body {text-align: center;}
label {font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; color: black;}
input[type=text], input[type=password] {
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    width: 50%; /* Full width */
    padding: 9px; /* Some padding */  
    border: 1px solid #ccc; /* Gray border */
    border-radius: 4px; /* Rounded borders */
    box-sizing: border-box; /* Make sure that padding and width stays in place */
    margin-top: 6px; /* Add a top margin */
    margin-bottom: 16px; /* Bottom margin */
    resize: vertical /* Allow the user to vertically resize the textarea (not horizontally) */
}
input[type=submit] {background-color: #012B74; color: white; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer;}
input[type=submit]:hover {background-color: #013A9E;}
button {background-color: #012B74; color: white; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer;}
button:hover {background-color: #013A9E;}
hr { border: 0; height: 1.5px; background: #333; background-image: linear-gradient(to right,#ccc,#012B74,#ccc); }
body {
   color: Black;
   font-family: 'Roboto', Verdana;
   font-size: 15px;
   background-image: url("pic/no.jpg"); 
   background-size: cover;
   background-repeat: no-repeat;
   background-attachment: fixed;
   background-position: center;
   text-align: center;
}
</style>