<?php
# Batch File to Execute
$cmd = 'exportupdate.bat';
$exe = shell_exec($cmd);
$result = "Re-Export Update Complete";
echo $result;

# Redirect After Complete Re-Export
redirect("front.php");

# Create & Define Redirect Function
function redirect($url) {
    ob_start();
    header('Location: '.$url);
    ob_end_flush();
    die();
}
?>