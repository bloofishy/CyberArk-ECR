<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<ul>
<li><a href="front.php">prev</a></li>
<li><a href="front.php"><img src="home.png" align="top" height=15px> CyberArk Extensive Customized Reporting</a></li>
<li><a href="report-template.php">Report</a></li>
<li><a href="audit-compliance.php">Audit</a></li>
<li style="float:right"><a class="active" href="index.php">root</a></li>
</ul><br><br><br>
<font size=4>Audit Compliance Template<br></font>
<br>
<p>Here's a list of audit compliance policies</p>
<div class="menu">
<a class="cyberblue" href="audit-compliance-mas.php"><p>________________<br><br><br>MAS-TRM<br><font size=1><br>Monetary Authority of Singapore Technology Risk Management Guidelines<br><br><br></font>‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾</p></a>
<a class="cyberblue" href="audit-compliance-pci.php"><p>________________<br><br><br>PCI-DSS<br><font size=1><br>Payment Card Industry<br>Data Security Standard<br><br><br><br></font>‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾</p></a>
<a class="cyberblue" href="audit-compliance-gdpr.php"><p>________________<br><br><br>GDPR<br><font size=1><br>General Data Protection Regulation<br><br><br><br><br></font>‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾</p></a>
</div>
</html>

<style>
a { color: #FFF; text-decoration: none; transition: all 0.5s ease 0s; }
.menu { width: 600px; margin: 30px auto; }
.menu a { width: 190px; height: 190px; display: block; margin: 4px; text-align: center; float:left; opacity: 0.8; }
.cyberblue { background: #012B74; }
a:hover { opacity: 1; }
</style>