<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<ul>
<li><a href="front.php">prev</a></li>
<li><a href="front.php"><img src="home.png" align="top" height=15px> CyberArk Extensive Customized Reporting</a></li>
<li><a href="report-template.php">Report</a></li>
<li><a href="audit-compliance.php">Audit</a></li>
<li style="float:right"><a class="active" href="index.php">root</a></li>
</ul><br><br><br>
<font size=4>Generic CyberArk Report Template(s)<br></font>
<br>
<p>Here's a list of generic pre-defined CyberArk report templates - created with reference to customer's feedback and requests (or their requirement)</p>
<div class="menu">
<a class="cyberblue" href="report-template-nonactive.php">Non-Active User Report</a>
<a class="cyberblue" href="report-template-ext.php">Ext User Report</a>
<a class="cyberblue" href="report-template-group.php">Group Member Report</a>
<a class="cyberblue" href="report-template-mps.php">Master Policy Report</a>
<a class="cyberblue" href="report-template-login.php">Successful Login Report</a>
<a class="cyberblue" href="report-template-endpoint.php">Endpoint OS Report</a>
<a class="cyberblue" href="report-template-review.php">Session Review Report</a>
<a class="cyberblue" href="report-template-activities.php">Session Activities Report</a>
<a class="cyberblue" href="report-template-session.php">Session Rec Report</a>
</div>
</html>

<style>
a { color: #FFF; text-decoration: none; transition: all 0.5s ease 0s; }
.menu { width: 600px; margin: 30px auto; }
.menu a { width: 190px; height: 190px; line-height: 190px; display: block; margin: 4px; text-align: center; float:left; opacity: 0.8; }
.cyberblue { background: #012B74; }
a:hover { opacity: 1; }
</style>