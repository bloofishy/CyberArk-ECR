<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<ul>
<li><a href="audit-compliance.php">prev</a></li>
<li><a href="front.php"><img src="home.png" align="top" height=15px> CyberArk Extensive Customized Reporting</a></li>
<li><a href="report-template.php">Report</a></li>
<li><a href="audit-compliance.php">Audit</a></li>
<li style="float:right"><a class="active" href="index.php">root</a></li>
</ul><br><br><br>
<font size=4>Payment Card Industry - Data Security Standard<br></font>
<br>
<p>The PCI-DSS has 4 areas that are relevant to CyberArk's Privilege Account Security solution. Here's a selection of reports with reference to specific compliance policies from the PCI-DSS.</p>

<div class="menu">
<p><font size=3>– Build and Maintain a Secure Network –</font></p>
<a class="cyberblue" href="audit-compliance-pci-2.php"><p><br>(2) Do not use vendor-supplied defaults for system passwords and other security parameters</p></a>
</div>

<div class="menu">
<p><font size=3>– Implement Strong Access Control Measures –</font></p>
<a class="cyberblue" href="audit-compliance-pci-7.php" style="margin-bottom:0px;"><p><br>(7) Restrict access to cardholder data by business need-to-know</p></a>
<a class="cyberblue" href="audit-compliance-pci-8.php"><p><br>(8) Assign a unique ID to each person with a computer access</p></a>
</div>

<div class="menu">
<p><font size=3>– Regularly Monitor and Test Networks –</font></p>
<a class="cyberblue" href="audit-compliance-pci-10.php"><p><br>(10) Track and monitor all access to network resrouces and cardholder data</p></a>
</div>

<div class="menu">
<p><font size=3>– Maintain an Information Security Policy –</font></p>
<a class="cyberblue" href="audit-compliance-pci-12.php"><p><br>(12) Maintain a policy that addresses infromation security</p></a>
</div>
</html>

<style>
a { color: #FFF; text-decoration: none; transition: all 0.5s ease 0s; }
.menu { width: 750px; margin: 30px auto; }
.menu a { width: 725px; height: 90px; display: block; margin: 4px; text-align: left; float:left; opacity: 0.8; margin-bottom: 30px; margin-top: 10px; padding-left: 15px; }
.cyberblue { background: #012B74; }
a:hover { opacity: 1; }
</style>