<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="audit-compliance-gdpr-response.php"; require 'topcontent.php'; ?>
<font size=4>Prior to and in Responding to a Breach (ref. Art 33)<br></font>
<p align=left><font size=4>GDPR Article 33 – Notification of a Personal Data Breach to the Supervisory Authority</font><br>The controller shall document any personal data breaches, comprising the facts relating to the personal data breach, its effects and the remedial action taken. That documentation shall enable the supervisory authority to verify compliance with this Article.</p>
<button class="collapsible"><b>CyberArk Solution</b></button>
<div class="content">
<p><b>Recording of Privilege Session Activities</b> – To detect the misuse of privilege credentials relating to a breach of personal data early in the attack life cycle, the CyberArk solution offers live monitoring and recording of user activities within the speciifc privilege session. In addition, accounting for who has accessed what personal data on which IT systems when.
</div>
<hr>

<!---
<html><body><form action='' method='post'>
<p>
<label for="new">Add to List:</label>
<input type='text' name='newitem' id='newitem'/>
<input type='submit' name='add' value='Add' />
<input type='submit' name='reset' value='Reset' />
</p>
<?php
# session_start();
/* #Filter Code Stuff
if (isset($_POST['add'])) {
if(!array_key_exists("list", $_SESSION)) { $_SESSION["list"] = array(); }
array_push($_SESSION["list"], $_POST["newitem"]);
}
if(isset($_POST['reset'])) { $_SESSION["list"] = array(); }
if(array_key_exists("list", $_SESSION)) {
echo "Existing List ( ";
echo implode(" + ", $_SESSION["list"]);
echo " ) ";
}
*/
?>
</form></body></html>
--->

<p align="left"><font size=2.5>- <b>PSM</b> Linux SSH Keystroke Logging </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'Keystroke Logging'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

$sessionlist = [];
# Find Unique Session ID
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$info = $row['CAAInfo2'];
	$infoex = explode(';',$info);
	$session = explode('=',$infoex[5])[1];
	if (!in_array($session,$sessionlist)) { array_push($sessionlist,$session); }
}

foreach ($sessionlist as $sessionid) {
echo "<button class='collapsible1'><b>".$sessionid."</b></button>";
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'Keystroke Logging'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

echo "<div class='content1'>";
echo "<br>";
echo "<table border=1> <tr>";
echo "<th style='width:80px'>Date</th>";
echo "<th style='width:80px'>Time</th>";
echo "<th style='width:80px'>App</th>";
echo "<th style='width:150px'>Target IP</th>";
echo "<th style='width:150px'>Execute</th>";
echo "<th style='width:80px'>Acc</th>";
echo "<th style='width:80px'>User</th>";
echo "</tr>";

# Print Result to the Report Table
	while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAAActivityID'];
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$info = $row['CAAInfo2'];
	$infoex = explode(';',$info);
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	$int = $row['CAAInterfaceId'];
	$session = explode('=',$infoex[5])[1];
	if ($sessionid === $session) {
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".explode('=',$infoex[1])[1]."</td>";
	echo "<td>".explode('=',$infoex[2])[1]."</td>";
	echo "<td>".explode('=',$infoex[0])[1]."</td>";
	echo "<td>".explode('=',$infoex[8])[1]."</td>";
	echo "<td>".$name."</td>";
	echo "</tr>";
		}
	}
echo "</table><br>";
echo "</div>";
echo "<br>";
}
sqlsrv_free_stmt ($state);
?>
<hr>

<p align="left"><font size=2.5>- <b>PSM</b> Window RDP Event Title </font></p>
<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'Window Title'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

$winsessionlist = [];
# Find Unique Session ID
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$info = $row['CAAInfo2'];
	$infoex = explode(';',$info);
	$winsession = explode('=',$infoex[8])[1];
	if (!in_array($winsession,$winsessionlist)) { array_push($winsessionlist,$winsession); }
}

foreach ($winsessionlist as $winsessionid) {
echo "<button class='collapsible1'><b>".$winsessionid."</b></button>";
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CALog WHERE CAAAction = 'Window Title'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

echo "<div class='content1'>";
echo "<br>";
echo "<table border=1> <tr>";
echo "<th style='width:80px'>Date</th>";
echo "<th style='width:80px'>Time</th>";
echo "<th style='width:80px'>App</th>";
echo "<th style='width:150px'>Target IP</th>";
echo "<th style='width:150px'>Execute</th>";
echo "<th style='width:80px'>Acc</th>";
echo "<th style='width:80px'>User</th>";
echo "</tr>";

# Print Result to the Report Table
	while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAAActivityID'];
	$time = $row['CAATime'];
	$action = $row['CAAAction'];
	$info = $row['CAAInfo2'];
	$infoex = explode(';',$info);
	$safe = $row['CAASafeName'];
	$file = $row['CAAInfo1'];
	$name = $row['CAAUserName'];
	$int = $row['CAAInterfaceId'];
	$session = explode('=',$infoex[5])[1];
	if ($winsessionid === $winsession) {
	echo "<tr>";
	echo "<td>".$time->format("d-m-Y")."</td>";
	echo "<td>".$time->format("H:i:s")."</td>";
	echo "<td>".explode('=',$infoex[1])[1]."</td>";
	echo "<td>".explode('=',$infoex[2])[1]."</td>";
	echo "<td>".explode('=',$infoex[0])[1]."</td>";
	echo "<td>".explode('=',$infoex[10])[1]."</td>";
	echo "<td>".$name."</td>";
	echo "</tr>";
		}
	}
echo "</table><br>";
echo "</div>";
echo "<br>";
}
sqlsrv_free_stmt ($state);
?>
<hr>


</body>
</html>
<script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}

var coll = document.getElementsByClassName("collapsible1");
var x;

for (x = 0; x < coll.length; x++) {
  coll[x].addEventListener("click", function() {
    this.classList.toggle("active1");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
.collapsible {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  background-color: rgba(150, 150, 150, 0.7);
  color: black;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: 2px solid black;
  text-align: left;
  outline: none;
  font-size: 15px;
  border-bottom: 0px solid black;
  transition: all 0.5s ease 0s;
}
.active, .collapsible:hover { background-color: #012B74; color: white; }
.collapsible:after { content: '\002B'; color: black; font-weight: bold; float: right; margin-left: 5px; }
.active:after { color: white; content: "\2212"; }
.content { padding: 0 18px; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; background-color: rgba(255, 255, 255, 0.7); border-left: 2px solid black; border-right: 2px solid black; border-bottom: 2px solid black; font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; text-align: left; }

.collapsible1 { font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; background-color: #012B74; color: white; cursor: pointer; padding: 18px; width: 100%; border: 2px solid black; text-align: left; outline: none; font-size: 15px; border-bottom: 0px solid black; transition: all 0.5s ease 0s; }
.active1, .collapsible1:hover { background-color: rgba(255, 125, 73, 0.9); color: black; }
.active1:after { color: black; content: "\2212"; }
.collapsible1:after { content: '\002B'; color: white; font-weight: bold; float: right; margin-left: 5px; }
.content1 { padding: 0 18px; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; background-color: rgba(255, 255, 255, 0.7); border-left: 2px solid black; border-right: 2px solid black; border-bottom: 2px solid black; font-family: "Trebuchet MS", Arial, Helvetica, sans-serif; text-align: left; }
</style>