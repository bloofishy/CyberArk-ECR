<html>
<title>CyberArk ECR</title>
<head><link rel="stylesheet" type="text/css" href="stylesheet.css"></head>
<body>
<?php $prev="report-template.php"; require 'topcontent.php'; ?>
<font size=4>CyberArk Endpoint Report<br></font>
<p>It's a report template created to show the different endpoints (define from IP address) within CyberArk with the relevant safe, platform and the privilege account it is tied to. It further helps to identify the relationship of the endpoint to it's corresponding safe and platform. </p>
<hr>

<table border=1 id=T0> <tr>
<th>Safe ID</th>
<th>Safe</th>
<th>File</th>
<th>Platform</th>
<th>IP Address</th>
<th>Account</th>
</tr>

<?php
# Specifying the Database with SQL Authentication Cred
$serverName = "KIT-EXPORT\\SQLEXP";
$connectionInfo = array("Database"=>"CyberArk", "UID"=>"test", "PWD"=>"Cyberark1");
$conn = sqlsrv_connect($serverName, $connectionInfo);

# Prepare SQL Queries for the Database
$query = "SELECT * FROM dbo.CAFiles WHERE CAFFileName LIKE 'Operating System%'";
$state = sqlsrv_query($conn, $query);
if ($state === false) { die (print_r(sqlsrv_errors(), true)); }

# Print Result to the Report Table
while ($row = sqlsrv_fetch_array($state, SQLSRV_FETCH_ASSOC)) {
	$identifier = $row['CAFSafeID'];
	$name = $row['CAFSafeName'];
	$file = $row['CAFFileName'];
	$fileinfo = explode('-',$file);
		echo "<tr>";
		echo "<td>".$identifier."</td>";
		echo "<td>".$name."</td>";
		echo "<td>".$file."</td>";
		echo "<td>".$fileinfo[1]."</td>";
		echo "<td>".$fileinfo[2]."</td>";
		echo "<td>".$fileinfo[3]."</td>";
		echo "</tr>";
}
sqlsrv_free_stmt ($state);
?>
</table><?php require 'exportexcel.php'; ?>
<p align="right"><button style="width:95px" class="toEnterStore0" onclick="exportTableToExcel('T0', 'Generic-Report-Endpoint-<?php echo date("d-m-Y"); ?>')"><font size = 1.5>Export to Excel</font></button></p>
<hr>
</body>
</html>
<style>
th {background-color: #012B74;}
.active {background-color: #012B74;}
tr:nth-child(odd){background-color: rgba(255, 255, 255, 0.7);}
tr:nth-child(even){background-color: rgba(255, 255, 255, 0.7);}
tr:hover {background-color: rgba(255, 125, 73, 0.7);}
</style>